# Constrained Sorting historical Git diffs

These eight checkpoints trace recoverable source from the November 2026 web prototype to the first-push package. The original 1999 Pascal program and its manuscript are described in the project history.

The first patch adds a playable checkpoint from an empty directory. Each following patch compares two checkpoints. The conversations and design notes record decisions between these checkpoints. Original source bytes for some interim revisions are unavailable. Reconstructed fixture checkpoints are identified below, and the input fixtures are included under `evidence/`. The archive sequence numbers identify checkpoints, while future repository commits track public releases.

## Version index

| Patch | Checkpoint | Source | Provenance |
| --- | --- | --- | --- |
| [01](patches/01-v6-clusters.patch) | V6 cluster layout | `v6-layout-frame.html` | Reconstructed from the saved V6 viewport fixture by removing its seeded board and scrollbar test harness. |
| [02](patches/02-v7-wrap.patch) | V7 wrap adjustment | `v7-layout-frame.html` | Reconstructed from the saved V7 viewport fixture by removing its seeded board and scrollbar test harness. |
| [03](patches/03-viewport-margin.patch) | Small-screen margin | `wrap-viewport.html` | Reconstructed from the wrap fixture by removing its scrollbar test styling. |
| [04](patches/04-group-width-baseline.patch) | Last free-grouping baseline | `expert-baseline.html` | Exact saved source used as the starting point for named-category play. |
| [05](patches/05-score-and-audio.patch) | Named categories, points, and audio | `sound-test.html` | Reconstructed from the saved sound fixture by removing its oscillator probe. |
| [06](patches/06-cricket-formats.patch) | Four cricket formats | `constrained-sorting.html` | Exact saved full-format HTML. Includes the four cricket decks and the compact two-part card labels. |
| [07](patches/07-category-order-and-fanfare.patch) | Direct box targets and fanfare | `finale.html` | Exact saved standalone HTML, with expanded rosters, singular category order, and the fuller fanfare. |
| [08](patches/08-first-push-source.patch) | First-push source | `release source` | Release index, five JSON decks, and standalone demo builder. |

## Reconstruct a checkpoint

Extract this archive. In a separate empty directory, set `ARCHIVE` to the absolute path of the extracted `constrained-sorting-git-diffs` folder. Run:

```sh
ARCHIVE='/path/to/constrained-sorting-git-diffs'
for patch in "$ARCHIVE"/patches/*.patch; do
  git apply --check "$patch" && git apply "$patch" || break
  name=${patch##*/}
  shasum -a 256 -c "$ARCHIVE/checksums/${name%%-*}.sha256" || break
done
```

Stop after the checkpoint you want. Earlier checkpoints open directly as `index.html`. The release checkpoint loads external JSON and should be served over HTTP, for example with `python3 -m http.server 8000`.

Every patch was applied in order to an empty replay directory and checked byte for byte against the corresponding checkpoint. Patch 08 reproduces the packaged `index.html`, `games/*/deck.json`, and `tools/build-demo.py`. Release documentation and the archive itself are separate from the replayable source.
